def func1():
    print("func1")