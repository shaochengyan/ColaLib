def para2dict(**kwargs):
    """将函数参数以命名函数的形式给出,然后返回dict"""
    return kwargs